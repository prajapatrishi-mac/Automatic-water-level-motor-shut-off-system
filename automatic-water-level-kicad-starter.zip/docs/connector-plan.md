# Connector Plan (proposed)

This plan is for an Arduino UNO expansion/breakout PCB using external modules. Confirm exact module pin labels before wiring.

| Connector | Proposed pins | Purpose |
|---|---|---|
| J1 | Arduino UNO shield headers | UNO power and GPIO breakout |
| J2 | `5V`, `GND`, `SENSOR_OUT` | Sensor module (only if compatible with 5 V logic) |
| J3 | `5V`, `GND`, `RELAY_IN` | Relay module input (confirm active HIGH/LOW) |
| J4 | `SW_IN`, `GND` | Low-voltage switch input |
| J5 | `MOTOR_SUPPLY+`, `MOTOR_SUPPLY-` | External low-voltage motor supply terminal |
| J6 | `MOTOR+`, `MOTOR-` | Motor/pump terminal only if the selected relay module and current ratings support it |

## Suggested signal mapping (must be confirmed in code)
- `SENSOR_OUT` → Arduino digital input, e.g. D2
- `RELAY_IN` → Arduino digital output, e.g. D8
- `SW_IN` → Arduino digital input, e.g. D3 with a suitable pull-up/pull-down arrangement
- `5V` and `GND` → only for modules whose voltage requirements are verified

These are suggestions, not confirmed pin assignments. The actual wiring must match the Arduino sketch and the exact sensor/relay modules.

## Before fabrication
1. Select the exact Arduino UNO header footprint and module connector pitch.
2. Confirm whether the sensor output is analog or digital and its voltage range.
3. Confirm relay module input voltage, trigger polarity, contact ratings, and motor startup current.
4. Size copper traces and terminals for the motor current.
5. Keep motor current paths separate from sensitive signal wiring where practical.
6. Add mounting holes, labels, copper zones, and clearances.
7. Run ERC and DRC and inspect the board in 3D view.
8. Have an experienced adult review it before use.
