# Automatic Water Level Motor Shut-Off — KiCad Starter

This is a **starter KiCad project**, not a manufacturing-ready PCB.

## Included
- `automatic_water_level.kicad_pro` — project settings
- `automatic_water_level.kicad_sch` — schematic starter sheet
- `automatic_water_level.kicad_pcb` — PCB outline starter
- `docs/connector-plan.md` — proposed connector signals and safety notes
- `BOM.csv` — starter bill of materials

## Important limitations
The schematic and board are intentionally **not fully designed or routed**. The PCB is an outline/layout starting point. Before ordering a board, add and verify footprints, electrical rules, net connections, mounting holes, clearances, and routing in KiCad's Schematic Editor and PCB Editor.

This design assumes a **low-voltage DC motor/pump only**. Do not connect household AC mains to this board. The relay module and battery must be compatible with the motor and supply. Ask an experienced adult to check the design before powering it.

A soil-moisture probe is not a reliable water-depth sensor. Use a sensor designed for the intended water-level measurement and confirm its electrical output before connecting it to the Arduino.
